select Date as "일자", sum(firstopen) as "abx:firstopen 수행 유저", 
sum(login) as "abx:login 수행 유저", 
sum(purchase) as "abx:purchase 수행 유저"
from(
    select cast(substr(server_datetime, 1,10) as date) AS Date,
    count(case when event_name = 'abx:firstopen'then event_name end) as firstopen,
    count(case when event_name = 'abx:login'then event_name end) as login,
    count(case when event_name = 'abx:purchase'then event_name end) as purchase
    from event
    where event_name='abx:firstopen' or event_name='abx:login' or event_name='abx:purchase'
    group by event_name, cast(substr(server_datetime, 1,10) as date)
)where firstopen!=0 or login!=0 or purchase!=0
group by Date
having Date between date('2018-05-02') and date('2018-05-16')
order by Date