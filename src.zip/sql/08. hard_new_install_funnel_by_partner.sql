select partner,
count(case when event_name = 'abx:firstopen'then event_name end) as "new_install_user",
count(case when event_name = 'abx:firstopen'then event_name end) as "abx:firstopen 수행 유저",
count(case when event_name = 'abx:login'then event_name end) as "abx:login 수행 유저",
count(case when event_name = 'abx:purchase'then event_name end) as "abx:purchase 수행 유저"
from (
    select a.identity_adid, a.os, a.model, a.country, a.event_name, a.log_id, a.server_datetime, a.quantity, a.price, b.partner, b.campaign, b.tracker_id, b.attribution_type
    from event a, attribution b 
    where a.identity_adid = b.identity_adid
    and b.partner!='')
where event_name='abx:firstopen' or event_name='abx:login' or event_name='abx:purchase'
group by partner
;