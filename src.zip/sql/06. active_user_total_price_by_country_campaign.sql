select a.country as country, b.campaign AS campaign_id, count(a.identity_adid) AS active_user, sum(a.price) as "구매 금액"
from event a, attribution b 
where a.identity_adid = b.identity_adid
group by a.country, b.campaign
having campaign!=''
order by country, campaign
;