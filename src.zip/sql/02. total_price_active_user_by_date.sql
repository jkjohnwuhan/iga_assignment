select cast(substr(server_datetime, 1,10) as date) AS Date, count(distinct(identity_adid)) AS ActiveUser, sum(price) as "구매 금액"
from event 
group by cast(substr(server_datetime, 1,10) as date)
having cast(substr(server_datetime, 1,10) as date) between date('2018-05-02') and date('2018-05-16')
order by cast(substr(server_datetime, 1,10) as date);