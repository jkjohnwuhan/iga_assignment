select campaign, count(identity_adid) as ActiveUser 
from attribution
group by campaign
having campaign != ''
order by campaign
;