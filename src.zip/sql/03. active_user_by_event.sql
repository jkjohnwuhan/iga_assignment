select event_name, count(identity_adid) as ActiveUser 
from event
group by event_name
order by event_name
;