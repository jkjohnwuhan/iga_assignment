select b.campaign AS campaign_id, count(a.identity_adid) AS ActiveUser, sum(a.price) as "구매 금액"
from event a, attribution b 
where a.identity_adid = b.identity_adid
group by b.campaign
having campaign!=''
order by campaign
;