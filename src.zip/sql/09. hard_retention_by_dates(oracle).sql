SELECT * FROM(
	SELECT DISTINCT identity_adid, to_date(substr(server_datetime,1,11),'YYYY-MM-DD') AS server_date FROM (
		SELECT DISTINCT identity_adid, event_name, server_datetime
		FROM(
			SELECT a.* 
			FROM EVENT a, ATTRIBUTION b 
			WHERE a.IDENTITY_ADID=b.IDENTITY_ADID
		)
		order by identity_adid, server_datetime
	) WHERE event_name='abx:firstopen'
)
PIVOT (
	COUNT(IDENTITY_adid) FOR SERVER_DATE IN (
	'2018-05-02' AS "new_user", 
	'2018-05-02' AS "D+0", 
	'2018-05-03' AS "D+1",
	'2018-05-04' AS "D+2",
	'2018-05-05' AS "D+3",
	'2018-05-06' AS "D+4",
	'2018-05-07' AS "D+5",
	'2018-05-08' AS "D+6",
	'2018-05-09' AS "D+7"
	)
)
;