from io import StringIO
from io import BytesIO
from pyarrow import csv,parquet

import json
import boto3
import urllib.parse
import pandas as pd
import pyarrow as pa

endpoint_url = '*'
access_key = '*'
secret_key = '*'

s3_client = boto3.client('s3', region_name='*', endpoint_url=endpoint_url, aws_access_key_id=access_key, aws_secret_access_key=secret_key)
s3_resource = boto3.resource('s3', region_name='*', endpoint_url=endpoint_url, aws_access_key_id=access_key, aws_secret_access_key=secret_key)

def lambda_handler(event, context):
    csv_buffer = StringIO()
    par_buffer = BytesIO()
    
    bucket = event['Records'][0]['s3']['bucket']['name']
    csv = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    dest = csv.replace(".csv", "")
    name = csv.replace('csv', 'parquet')
    
    if name == 'part-00000':
        col = ['identity_adid', 'os', 'model', 'country', 'event_name', 'log_id', 'server_datetime', 'quantity', 'price']
        resp = s3_client.get_object(Bucket=bucket, Key=csv)
        data = pd.read_csv(resp['Body'], sep=',')
        data.columns = col
        data = data.fillna(0)
        data = data.astype({'identity_adid':'str','os':'str','model':'str','quantity':'int', 'price':'float32', 'server_datetime':'str'})
    elif name == 'part-00001':
        col = ['partner', 'campaign', 'server_datetime', 'tracker_id', 'log_id', 'attribution_type', 'identity_adid']
        data = pd.read_csv(resp['Body'], sep=',')
        data.columns = col
        data = data.astype({'identity_adid':'str', 'server_datetime':'str'})
    else:
        print("Not a valid input.")
    
    try:
        data.to_parquet(par_buffer, engine='pyarrow', index=False)
        s3_resource.Object(f'destination-part/{dest}', f'{name}').put(Body=par_buffer.getvalue())
    except Exception as e:
        print("Data Invalid.", e)